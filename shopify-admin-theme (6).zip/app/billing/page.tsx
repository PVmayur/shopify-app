"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Loader2, Crown, Zap, Rocket } from "lucide-react"

interface BillingPlan {
  id: string
  name: string
  price: number
  features: string[]
  productLimit: number
  trialDays: number
}

export default function BillingPage() {
  const searchParams = useSearchParams()
  const [plans, setPlans] = useState<BillingPlan[]>([])
  const [activeSubscription, setActiveSubscription] = useState(null)
  const [loading, setLoading] = useState(true)
  const [subscribing, setSubscribing] = useState("")

  const shop = searchParams.get("shop")
  const success = searchParams.get("success")
  const error = searchParams.get("error")

  useEffect(() => {
    if (shop) {
      fetchBillingInfo()
    }
  }, [shop])

  const fetchBillingInfo = async () => {
    try {
      const response = await fetch(`/api/billing?shop=${shop}`)
      const data = await response.json()

      if (response.ok) {
        setPlans(data.plans)
        setActiveSubscription(data.activeSubscription)
      }
    } catch (error) {
      console.error("Failed to fetch billing info:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubscribe = async (planId: string) => {
    setSubscribing(planId)

    try {
      const response = await fetch("/api/billing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shop, planId }),
      })

      const data = await response.json()

      if (response.ok && data.confirmationUrl) {
        window.location.href = data.confirmationUrl
      } else {
        alert(data.error || "Failed to create subscription")
      }
    } catch (error) {
      alert("Failed to create subscription")
    } finally {
      setSubscribing("")
    }
  }

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case "basic":
        return <Zap className="w-6 h-6" />
      case "professional":
        return <Crown className="w-6 h-6" />
      case "enterprise":
        return <Rocket className="w-6 h-6" />
      default:
        return <Zap className="w-6 h-6" />
    }
  }

  const getPlanColor = (planId: string) => {
    switch (planId) {
      case "basic":
        return "border-blue-200 hover:border-blue-300"
      case "professional":
        return "border-purple-200 hover:border-purple-300 ring-2 ring-purple-200"
      case "enterprise":
        return "border-orange-200 hover:border-orange-300"
      default:
        return "border-gray-200"
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Unlock the full potential of your Shopify store with RankOptim's powerful management tools
          </p>

          {success && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg inline-flex items-center gap-2 text-green-700">
              <CheckCircle className="w-5 h-5" />
              <span>Subscription activated successfully!</span>
            </div>
          )}

          {error && (
            <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg inline-flex items-center gap-2 text-red-700">
              <span>There was an error processing your subscription. Please try again.</span>
            </div>
          )}
        </div>

        {activeSubscription && (
          <div className="mb-8 p-6 bg-green-50 border border-green-200 rounded-lg">
            <h3 className="text-lg font-semibold text-green-800 mb-2">Current Subscription</h3>
            <p className="text-green-700">You have an active {activeSubscription.name} subscription.</p>
          </div>
        )}

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <Card key={plan.id} className={`relative ${getPlanColor(plan.id)} transition-all duration-200`}>
              {plan.id === "professional" && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-purple-600 text-white px-3 py-1">Most Popular</Badge>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-4 text-gray-700">{getPlanIcon(plan.id)}</div>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="text-4xl font-bold text-gray-900">
                  ${plan.price}
                  <span className="text-lg font-normal text-gray-600">/month</span>
                </div>
                <CardDescription>{plan.trialDays}-day free trial</CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={subscribing === plan.id || !!activeSubscription}
                  className="w-full mt-6"
                  variant={plan.id === "professional" ? "default" : "outline"}
                >
                  {subscribing === plan.id ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : activeSubscription ? (
                    "Current Plan"
                  ) : (
                    `Start ${plan.trialDays}-Day Trial`
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">All plans include our core features and dedicated support</p>
          <Button variant="ghost" onClick={() => (window.location.href = `/admin?shop=${shop}`)}>
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  )
}
