"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Loader2, AlertCircle } from "lucide-react"

export default function InstallPage() {
  const searchParams = useSearchParams()
  const [installing, setInstalling] = useState(false)
  const [installed, setInstalled] = useState(false)
  const [error, setError] = useState("")

  const shop = searchParams.get("shop")

  const handleInstall = async () => {
    if (!shop) {
      setError("Shop parameter is required")
      return
    }

    setInstalling(true)
    setError("")

    try {
      // Redirect to OAuth flow
      window.location.href = `/api/auth?shop=${shop}`
    } catch (err) {
      setError("Installation failed. Please try again.")
      setInstalling(false)
    }
  }

  useEffect(() => {
    // Check if we're returning from successful auth
    if (searchParams.get("installed") === "true") {
      setInstalled(true)
    }
  }, [searchParams])

  if (installed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <CardTitle className="text-2xl text-green-700">Installation Complete!</CardTitle>
            <CardDescription>RankOptim has been successfully installed to your Shopify store.</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button onClick={() => (window.location.href = `/admin?shop=${shop}`)} className="w-full">
              Open App
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-xl">R</span>
          </div>
          <CardTitle className="text-2xl">Install RankOptim</CardTitle>
          <CardDescription>
            Transform your Shopify store management with powerful tools for product optimization and bulk operations.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Smart image upload by SKU</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Bulk discount management</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Advanced product operations</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Complete operation history</span>
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-600 text-sm">
              <AlertCircle className="w-4 h-4" />
              <span>{error}</span>
            </div>
          )}

          <Button onClick={handleInstall} disabled={installing || !shop} className="w-full">
            {installing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Installing...
              </>
            ) : (
              "Install App"
            )}
          </Button>

          {!shop && (
            <p className="text-xs text-gray-500 text-center">This page should be accessed from the Shopify App Store</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
