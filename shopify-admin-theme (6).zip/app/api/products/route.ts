import { type NextRequest, NextResponse } from "next/server"
import { sessionManager } from "@/lib/shopify-session"
import { shopify } from "@/lib/shopify-app"

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const shop = url.searchParams.get("shop")
    const limit = url.searchParams.get("limit") || "50"
    const cursor = url.searchParams.get("cursor")

    if (!shop) {
      return NextResponse.json({ error: "Shop parameter required" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const client = new shopify.clients.Graphql({ session })

    const query = `
      query getProducts($first: Int!, $after: String) {
        products(first: $first, after: $after) {
          edges {
            node {
              id
              title
              handle
              status
              vendor
              productType
              createdAt
              updatedAt
              totalInventory
              images(first: 1) {
                edges {
                  node {
                    id
                    url
                    altText
                  }
                }
              }
              variants(first: 10) {
                edges {
                  node {
                    id
                    title
                    price
                    compareAtPrice
                    sku
                    inventoryQuantity
                    availableForSale
                  }
                }
              }
            }
            cursor
          }
          pageInfo {
            hasNextPage
            hasPreviousPage
          }
        }
      }
    `

    const variables = {
      first: Number.parseInt(limit),
      ...(cursor && { after: cursor }),
    }

    const response = await client.query({ data: { query, variables } })

    return NextResponse.json(response.body.data)
  } catch (error) {
    console.error("Products API error:", error)
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { shop, productId, updates } = await request.json()

    if (!shop || !productId || !updates) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const client = new shopify.clients.Graphql({ session })

    const mutation = `
      mutation productUpdate($input: ProductInput!) {
        productUpdate(input: $input) {
          product {
            id
            title
            status
          }
          userErrors {
            field
            message
          }
        }
      }
    `

    const variables = {
      input: {
        id: productId,
        ...updates,
      },
    }

    const response = await client.query({ data: { query: mutation, variables } })

    if (response.body.data?.productUpdate?.userErrors?.length > 0) {
      return NextResponse.json(
        {
          error: response.body.data.productUpdate.userErrors[0].message,
        },
        { status: 400 },
      )
    }

    return NextResponse.json(response.body.data.productUpdate.product)
  } catch (error) {
    console.error("Product update error:", error)
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}
