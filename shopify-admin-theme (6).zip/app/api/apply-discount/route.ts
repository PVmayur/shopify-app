import { type NextRequest, NextResponse } from "next/server"
import { sessionManager } from "@/lib/shopify-session"
import { shopify } from "@/lib/shopify-app"

export async function POST(request: NextRequest) {
  try {
    const { shop, discountPercentage, productIds, collectionIds } = await request.json()

    if (!shop || !discountPercentage) {
      return NextResponse.json({ error: "Shop and discount percentage required" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const client = new shopify.clients.Graphql({ session })

    // Get products to update
    let productsToUpdate = []

    if (productIds && productIds.length > 0) {
      // Update specific products
      const productQuery = `
        query getProducts($ids: [ID!]!) {
          nodes(ids: $ids) {
            ... on Product {
              id
              variants(first: 100) {
                edges {
                  node {
                    id
                    price
                    compareAtPrice
                  }
                }
              }
            }
          }
        }
      `

      const productResponse = await client.query({
        data: { query: productQuery, variables: { ids: productIds } },
      })

      productsToUpdate = productResponse.body.data.nodes
    } else if (collectionIds && collectionIds.length > 0) {
      // Update products in collections
      for (const collectionId of collectionIds) {
        const collectionQuery = `
          query getCollectionProducts($id: ID!, $first: Int!) {
            collection(id: $id) {
              products(first: $first) {
                edges {
                  node {
                    id
                    variants(first: 100) {
                      edges {
                        node {
                          id
                          price
                          compareAtPrice
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        `

        const collectionResponse = await client.query({
          data: { query: collectionQuery, variables: { id: collectionId, first: 250 } },
        })

        if (collectionResponse.body.data.collection) {
          productsToUpdate.push(...collectionResponse.body.data.collection.products.edges.map((edge) => edge.node))
        }
      }
    }

    // Apply discount to variants
    const results = []

    for (const product of productsToUpdate) {
      for (const variantEdge of product.variants.edges) {
        const variant = variantEdge.node
        const currentPrice = Number.parseFloat(variant.price)
        const discountedPrice = currentPrice * (1 - discountPercentage / 100)

        const mutation = `
          mutation productVariantUpdate($input: ProductVariantInput!) {
            productVariantUpdate(input: $input) {
              productVariant {
                id
                price
                compareAtPrice
              }
              userErrors {
                field
                message
              }
            }
          }
        `

        const variables = {
          input: {
            id: variant.id,
            price: discountedPrice.toFixed(2),
            compareAtPrice: variant.compareAtPrice || currentPrice.toFixed(2),
          },
        }

        const updateResponse = await client.query({ data: { query: mutation, variables } })
        results.push(updateResponse.body.data.productVariantUpdate)
      }
    }

    return NextResponse.json({
      success: true,
      updatedVariants: results.length,
      results,
    })
  } catch (error) {
    console.error("Apply discount error:", error)
    return NextResponse.json({ error: "Failed to apply discount" }, { status: 500 })
  }
}
