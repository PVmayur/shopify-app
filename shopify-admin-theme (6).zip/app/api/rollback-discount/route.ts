import { type NextRequest, NextResponse } from "next/server"
import { sessionManager } from "@/lib/shopify-session"
import { shopify } from "@/lib/shopify-app"

export async function POST(request: NextRequest) {
  try {
    const { shop, productIds, collectionIds } = await request.json()

    if (!shop) {
      return NextResponse.json({ error: "Shop parameter required" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const client = new shopify.clients.Graphql({ session })

    // Get products to rollback
    let productsToRollback = []

    if (productIds && productIds.length > 0) {
      const productQuery = `
        query getProducts($ids: [ID!]!) {
          nodes(ids: $ids) {
            ... on Product {
              id
              variants(first: 100) {
                edges {
                  node {
                    id
                    price
                    compareAtPrice
                  }
                }
              }
            }
          }
        }
      `

      const productResponse = await client.query({
        data: { query: productQuery, variables: { ids: productIds } },
      })

      productsToRollback = productResponse.body.data.nodes
    }

    // Rollback variants (restore from compareAtPrice)
    const results = []

    for (const product of productsToRollback) {
      for (const variantEdge of product.variants.edges) {
        const variant = variantEdge.node

        if (variant.compareAtPrice && Number.parseFloat(variant.compareAtPrice) > Number.parseFloat(variant.price)) {
          const mutation = `
            mutation productVariantUpdate($input: ProductVariantInput!) {
              productVariantUpdate(input: $input) {
                productVariant {
                  id
                  price
                  compareAtPrice
                }
                userErrors {
                  field
                  message
                }
              }
            }
          `

          const variables = {
            input: {
              id: variant.id,
              price: variant.compareAtPrice,
              compareAtPrice: null,
            },
          }

          const updateResponse = await client.query({ data: { query: mutation, variables } })
          results.push(updateResponse.body.data.productVariantUpdate)
        }
      }
    }

    return NextResponse.json({
      success: true,
      rolledBackVariants: results.length,
      results,
    })
  } catch (error) {
    console.error("Rollback discount error:", error)
    return NextResponse.json({ error: "Failed to rollback discount" }, { status: 500 })
  }
}
