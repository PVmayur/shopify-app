import { type NextRequest, NextResponse } from "next/server"
import { shopify } from "@/lib/shopify-app"

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const shop = url.searchParams.get("shop")

    if (!shop) {
      return NextResponse.json({ error: "Shop parameter is required" }, { status: 400 })
    }

    // Validate shop domain
    if (!shop.endsWith(".myshopify.com")) {
      return NextResponse.json({ error: "Invalid shop domain" }, { status: 400 })
    }

    const authRoute = await shopify.auth.begin({
      shop,
      callbackPath: "/api/auth/callback",
      isOnline: false,
      rawRequest: request,
      rawResponse: NextResponse.next(),
    })

    return NextResponse.redirect(authRoute)
  } catch (error) {
    console.error("Auth error:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}
