import { type NextRequest, NextResponse } from "next/server"
import { shopify } from "@/lib/shopify-app"
import { sessionManager } from "@/lib/shopify-session"

export async function GET(request: NextRequest) {
  try {
    const callback = await shopify.auth.callback({
      rawRequest: request,
      rawResponse: NextResponse.next(),
    })

    const { session } = callback

    if (!session) {
      return NextResponse.json({ error: "No session created" }, { status: 400 })
    }

    // Store session
    await sessionManager.storeSession(session)

    // Register webhooks
    await shopify.webhooks.register({ session })

    // Redirect to app
    const redirectUrl = `${process.env.SHOPIFY_APP_URL}/admin?shop=${session.shop}`
    return NextResponse.redirect(redirectUrl)
  } catch (error) {
    console.error("Auth callback error:", error)
    return NextResponse.json({ error: "Authentication callback failed" }, { status: 500 })
  }
}
