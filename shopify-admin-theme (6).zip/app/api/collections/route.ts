import { type NextRequest, NextResponse } from "next/server"
import { sessionManager } from "@/lib/shopify-session"
import { shopify } from "@/lib/shopify-app"

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const shop = url.searchParams.get("shop")

    if (!shop) {
      return NextResponse.json({ error: "Shop parameter required" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const client = new shopify.clients.Graphql({ session })

    const query = `
      query getCollections($first: Int!) {
        collections(first: $first) {
          edges {
            node {
              id
              title
              handle
              description
              productsCount
              image {
                id
                url
                altText
              }
            }
          }
        }
      }
    `

    const variables = { first: 250 }
    const response = await client.query({ data: { query, variables } })

    return NextResponse.json(response.body.data)
  } catch (error) {
    console.error("Collections API error:", error)
    return NextResponse.json({ error: "Failed to fetch collections" }, { status: 500 })
  }
}
