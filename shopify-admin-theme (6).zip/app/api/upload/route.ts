import { type NextRequest, NextResponse } from "next/server"
import { sessionManager } from "@/lib/shopify-session"
import { shopify } from "@/lib/shopify-app"
import JSZip from "jszip"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const shop = formData.get("shop") as string
    const file = formData.get("file") as File

    if (!shop || !file) {
      return NextResponse.json({ error: "Shop and file required" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const client = new shopify.clients.Graphql({ session })

    // Process ZIP file
    const arrayBuffer = await file.arrayBuffer()
    const zip = new JSZip()
    const zipContent = await zip.loadAsync(arrayBuffer)

    const uploadResults = []

    // Process each file in the ZIP
    for (const [filename, zipEntry] of Object.entries(zipContent.files)) {
      if (zipEntry.dir) continue

      // Extract SKU from filename (assuming format: SKU.jpg or folder/SKU.jpg)
      const sku = filename.split("/").pop()?.split(".")[0]
      if (!sku) continue

      try {
        // Get image data
        const imageData = await zipEntry.async("base64")
        const mimeType = filename.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg"

        // Find product by SKU
        const productQuery = `
          query findProductBySku($query: String!) {
            products(first: 1, query: $query) {
              edges {
                node {
                  id
                  title
                  variants(first: 1) {
                    edges {
                      node {
                        id
                        sku
                      }
                    }
                  }
                }
              }
            }
          }
        `

        const productResponse = await client.query({
          data: { query: productQuery, variables: { query: `sku:${sku}` } },
        })

        const products = productResponse.body.data.products.edges
        if (products.length === 0) {
          uploadResults.push({ sku, status: "error", message: "Product not found" })
          continue
        }

        const product = products[0].node

        // Upload image to Shopify
        const uploadMutation = `
          mutation productCreateMedia($media: [CreateMediaInput!]!, $productId: ID!) {
            productCreateMedia(media: $media, productId: $productId) {
              media {
                id
                status
              }
              mediaUserErrors {
                field
                message
              }
            }
          }
        `

        const mediaInput = {
          originalSource: `data:${mimeType};base64,${imageData}`,
          mediaContentType: "IMAGE",
        }

        const uploadResponse = await client.query({
          data: {
            query: uploadMutation,
            variables: {
              media: [mediaInput],
              productId: product.id,
            },
          },
        })

        if (uploadResponse.body.data.productCreateMedia.mediaUserErrors.length > 0) {
          uploadResults.push({
            sku,
            status: "error",
            message: uploadResponse.body.data.productCreateMedia.mediaUserErrors[0].message,
          })
        } else {
          uploadResults.push({ sku, status: "success", productTitle: product.title })
        }
      } catch (error) {
        uploadResults.push({ sku, status: "error", message: error.message })
      }
    }

    return NextResponse.json({
      success: true,
      results: uploadResults,
      totalProcessed: uploadResults.length,
    })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json({ error: "Failed to process upload" }, { status: 500 })
  }
}
