import { type NextRequest, NextResponse } from "next/server"
import { sessionManager } from "@/lib/shopify-session"
import { createRecurringCharge, getActiveSubscription, BILLING_PLANS } from "@/lib/billing"

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const shop = url.searchParams.get("shop")

    if (!shop) {
      return NextResponse.json({ error: "Shop parameter required" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const subscription = await getActiveSubscription(session)

    return NextResponse.json({
      plans: BILLING_PLANS,
      activeSubscription: subscription.data?.currentAppInstallation?.activeSubscriptions?.[0] || null,
    })
  } catch (error) {
    console.error("Billing GET error:", error)
    return NextResponse.json({ error: "Failed to fetch billing info" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { shop, planId } = await request.json()

    if (!shop || !planId) {
      return NextResponse.json({ error: "Shop and planId required" }, { status: 400 })
    }

    const sessions = await sessionManager.findSessionsByShop(shop)
    if (sessions.length === 0) {
      return NextResponse.json({ error: "No active session" }, { status: 401 })
    }

    const session = sessions[0]
    const result = await createRecurringCharge(session, planId)

    if (result.data?.appSubscriptionCreate?.userErrors?.length > 0) {
      return NextResponse.json(
        {
          error: result.data.appSubscriptionCreate.userErrors[0].message,
        },
        { status: 400 },
      )
    }

    return NextResponse.json({
      confirmationUrl: result.data?.appSubscriptionCreate?.confirmationUrl,
    })
  } catch (error) {
    console.error("Billing POST error:", error)
    return NextResponse.json({ error: "Failed to create subscription" }, { status: 500 })
  }
}
