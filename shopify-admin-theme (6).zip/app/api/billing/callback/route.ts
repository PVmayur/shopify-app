import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const shop = url.searchParams.get("shop")
    const charge_id = url.searchParams.get("charge_id")

    if (!shop) {
      return NextResponse.json({ error: "Shop parameter required" }, { status: 400 })
    }

    // Redirect back to billing page with success
    const redirectUrl = `${process.env.SHOPIFY_APP_URL}/billing?shop=${shop}&success=true`
    return NextResponse.redirect(redirectUrl)
  } catch (error) {
    console.error("Billing callback error:", error)
    const shop = new URL(request.url).searchParams.get("shop")
    const redirectUrl = `${process.env.SHOPIFY_APP_URL}/billing?shop=${shop}&error=true`
    return NextResponse.redirect(redirectUrl)
  }
}
