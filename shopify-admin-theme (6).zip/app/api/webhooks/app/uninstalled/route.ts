import { type NextRequest, NextResponse } from "next/server"
import { shopify } from "@/lib/shopify-app"
import { sessionManager } from "@/lib/shopify-session"

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const topic = request.headers.get("x-shopify-topic")
    const shop = request.headers.get("x-shopify-shop-domain")
    const hmac = request.headers.get("x-shopify-hmac-sha256")

    if (!shop || !hmac) {
      return NextResponse.json({ error: "Missing required headers" }, { status: 400 })
    }

    // Verify webhook
    const isValid = shopify.webhooks.verify(body, hmac)
    if (!isValid) {
      return NextResponse.json({ error: "Invalid webhook" }, { status: 401 })
    }

    // Clean up sessions for uninstalled app
    await sessionManager.deleteSessionsByShop(shop)

    console.log(`App uninstalled from shop: ${shop}`)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
