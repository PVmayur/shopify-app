import { type NextRequest, NextResponse } from "next/server"
import { shopify } from "@/lib/shopify-app"

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const shop = request.headers.get("x-shopify-shop-domain")
    const hmac = request.headers.get("x-shopify-hmac-sha256")

    if (!shop || !hmac) {
      return NextResponse.json({ error: "Missing required headers" }, { status: 400 })
    }

    // Verify webhook
    const isValid = shopify.webhooks.verify(body, hmac)
    if (!isValid) {
      return NextResponse.json({ error: "Invalid webhook" }, { status: 401 })
    }

    const product = JSON.parse(body)
    console.log(`Product created: ${product.title} in shop: ${shop}`)

    // Here you can add logic to sync product data, update analytics, etc.

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Product create webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
