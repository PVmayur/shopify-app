import { shopify } from "./shopify-app"
import type { Session } from "@shopify/shopify-api"

export interface BillingPlan {
  id: string
  name: string
  price: number
  features: string[]
  productLimit: number
  trialDays: number
}

export const BILLING_PLANS: BillingPlan[] = [
  {
    id: "basic",
    name: "Basic",
    price: 9.99,
    features: ["Up to 1,000 products", "Smart image upload", "Basic discount management", "Email support"],
    productLimit: 1000,
    trialDays: 7,
  },
  {
    id: "professional",
    name: "Professional",
    price: 29.99,
    features: [
      "Up to 10,000 products",
      "Advanced bulk operations",
      "Scheduled campaigns",
      "Priority support",
      "Advanced analytics",
    ],
    productLimit: 10000,
    trialDays: 7,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 99.99,
    features: ["Unlimited products", "Custom integrations", "Dedicated support", "Advanced reporting", "API access"],
    productLimit: -1,
    trialDays: 14,
  },
]

export async function createRecurringCharge(session: Session, planId: string) {
  const plan = BILLING_PLANS.find((p) => p.id === planId)
  if (!plan) {
    throw new Error("Invalid plan ID")
  }

  const client = new shopify.clients.Graphql({ session })

  const mutation = `
    mutation appSubscriptionCreate($name: String!, $lineItems: [AppSubscriptionLineItemInput!]!, $trialDays: Int, $returnUrl: URL!) {
      appSubscriptionCreate(name: $name, lineItems: $lineItems, trialDays: $trialDays, returnUrl: $returnUrl) {
        appSubscription {
          id
          status
        }
        confirmationUrl
        userErrors {
          field
          message
        }
      }
    }
  `

  const variables = {
    name: `RankOptim ${plan.name} Plan`,
    lineItems: [
      {
        plan: {
          appRecurringPricingDetails: {
            price: { amount: plan.price, currencyCode: "USD" },
          },
        },
      },
    ],
    trialDays: plan.trialDays,
    returnUrl: `${process.env.SHOPIFY_APP_URL}/billing/callback`,
  }

  const response = await client.query({ data: { query: mutation, variables } })
  return response.body
}

export async function getActiveSubscription(session: Session) {
  const client = new shopify.clients.Graphql({ session })

  const query = `
    query {
      currentAppInstallation {
        activeSubscriptions {
          id
          name
          status
          createdAt
          trialDays
          currentPeriodEnd
          lineItems {
            id
            plan {
              pricingDetails {
                ... on AppRecurringPricing {
                  price {
                    amount
                    currencyCode
                  }
                }
              }
            }
          }
        }
      }
    }
  `

  const response = await client.query({ data: query })
  return response.body
}

export async function cancelSubscription(session: Session, subscriptionId: string) {
  const client = new shopify.clients.Graphql({ session })

  const mutation = `
    mutation appSubscriptionCancel($id: ID!) {
      appSubscriptionCancel(id: $id) {
        appSubscription {
          id
          status
        }
        userErrors {
          field
          message
        }
      }
    }
  `

  const variables = { id: subscriptionId }
  const response = await client.query({ data: { query: mutation, variables } })
  return response.body
}
