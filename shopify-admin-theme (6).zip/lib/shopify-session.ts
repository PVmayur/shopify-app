import { Session } from "@shopify/shopify-api"

interface ShopifySessionData {
  shop: string
  accessToken: string
  scope: string
  expires?: Date
}

class ShopifySessionManager {
  private sessions: Map<string, ShopifySessionData> = new Map()

  async storeSession(session: Session): Promise<void> {
    const sessionData: ShopifySessionData = {
      shop: session.shop,
      accessToken: session.accessToken || "",
      scope: session.scope || "",
      expires: session.expires,
    }

    this.sessions.set(session.id, sessionData)
  }

  async loadSession(sessionId: string): Promise<Session | undefined> {
    const sessionData = this.sessions.get(sessionId)

    if (!sessionData) {
      return undefined
    }

    return new Session({
      id: sessionId,
      shop: sessionData.shop,
      state: "authenticated",
      isOnline: false,
      accessToken: sessionData.accessToken,
      scope: sessionData.scope,
      expires: sessionData.expires,
    })
  }

  async deleteSession(sessionId: string): Promise<boolean> {
    return this.sessions.delete(sessionId)
  }

  async findSessionsByShop(shop: string): Promise<Session[]> {
    const sessions: Session[] = []

    for (const [sessionId, sessionData] of this.sessions.entries()) {
      if (sessionData.shop === shop) {
        const session = new Session({
          id: sessionId,
          shop: sessionData.shop,
          state: "authenticated",
          isOnline: false,
          accessToken: sessionData.accessToken,
          scope: sessionData.scope,
          expires: sessionData.expires,
        })
        sessions.push(session)
      }
    }

    return sessions
  }

  async deleteSessionsByShop(shop: string): Promise<boolean> {
    let deleted = false

    for (const [sessionId, sessionData] of this.sessions.entries()) {
      if (sessionData.shop === shop) {
        this.sessions.delete(sessionId)
        deleted = true
      }
    }

    return deleted
  }
}

export const sessionManager = new ShopifySessionManager()
