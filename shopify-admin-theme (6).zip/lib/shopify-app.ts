import { shopifyApi, LATEST_API_VERSION, Session } from "@shopify/shopify-api"
import { MemorySessionStorage } from "@shopify/shopify-app-session-storage-memory"

const sessionStorage = new MemorySessionStorage()

export const shopify = shopifyApi({
  apiKey: process.env.SHOPIFY_API_KEY!,
  apiSecretKey: process.env.SHOPIFY_API_SECRET!,
  scopes: [
    "write_products",
    "read_products",
    "write_product_listings",
    "read_product_listings",
    "write_inventory",
    "read_inventory",
    "write_orders",
    "read_orders",
    "write_customers",
    "read_customers",
    "write_discounts",
    "read_discounts",
    "write_price_rules",
    "read_price_rules",
    "write_files",
    "read_files",
  ],
  hostName: process.env.SHOPIFY_APP_URL?.replace(/https?:\/\//, "") || "localhost:3000",
  hostScheme: "https",
  apiVersion: LATEST_API_VERSION,
  isEmbeddedApp: true,
  sessionStorage,
})

export async function getShopifySession(shop: string, accessToken: string): Promise<Session> {
  const session = new Session({
    id: `${shop}_session`,
    shop,
    state: "authenticated",
    isOnline: false,
    accessToken,
  })

  await sessionStorage.storeSession(session)
  return session
}

export async function getSessionFromStorage(sessionId: string): Promise<Session | undefined> {
  return await sessionStorage.loadSession(sessionId)
}

export async function deleteSession(sessionId: string): Promise<boolean> {
  return await sessionStorage.deleteSession(sessionId)
}
