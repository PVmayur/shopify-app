# RankOptim - Shopify Management Suite

A comprehensive Shopify app for advanced store management, featuring smart image uploads, bulk discount operations, and powerful product management tools.

## Features

- 🚀 **Smart Image Upload**: Upload hundreds of product images by SKU with intelligent ZIP processing
- 💰 **Bulk Discount System**: Apply percentage discounts across your catalog with advanced targeting
- 📊 **Advanced Product Management**: Comprehensive dashboard with bulk operations
- 🔄 **Operation History**: Complete tracking with rollback capabilities
- 💳 **Built-in Billing**: Professional subscription management
- 🔐 **Multi-store Support**: Secure session management for multiple stores

## Quick Start

### 1. Clone and Install
\`\`\`bash
git clone <your-repo>
cd rankoptim-shopify-app
npm install
\`\`\`

### 2. Environment Setup
\`\`\`bash
cp .env.example .env.local
\`\`\`

Fill in your Shopify app credentials:
\`\`\`env
SHOPIFY_API_KEY=your_api_key_here
SHOPIFY_API_SECRET=your_api_secret_here
SHOPIFY_APP_URL=https://your-app-domain.vercel.app
\`\`\`

### 3. Deploy to Vercel
\`\`\`bash
npm run build
vercel --prod
\`\`\`

### 4. Configure Shopify App
1. Update `shopify.app.toml` with your actual domain
2. Set up webhooks and OAuth URLs in Partner Dashboard

## Development

\`\`\`bash
npm run dev
\`\`\`

## Deployment

\`\`\`bash
npm run build
npm run start
\`\`\`

## Shopify App Store Submission

1. Test thoroughly on development store
2. Create app assets (icon, screenshots)
3. Submit through Partner Dashboard
4. Review process takes 5-10 business days

## Support

For issues or questions, please contact support through the Shopify Partner Dashboard.

## License

Private - All rights reserved
